document.addEventListener("DOMContentLoaded", () => {
  const filters = document.querySelectorAll(".filters button");
  const characterCards = document.querySelectorAll(".character-card");

  // Función para manejar el filtrado
  const filterCharacters = (category) => {
    characterCards.forEach((card) => {
      // Mostrar todas las tarjetas si la categoría es "all"
      if (category === "all" || card.classList.contains(category)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  };

  // Agregar evento a los botones de filtro
  filters.forEach((filter) => {
    filter.addEventListener("click", () => {
      // Quitar la clase "active" de todos los botones
      filters.forEach((btn) => btn.classList.remove("active"));

      // Agregar la clase "active" al botón seleccionado
      filter.classList.add("active");

      // Obtener la categoría y filtrar las tarjetas
      const category = filter.textContent.trim().toLowerCase();
      filterCharacters(category);
    });
  });

  // Mostrar todos los personajes por defecto
  filterCharacters("all");

  // Evento para el botón "Create Character"
  const createButton = document.querySelector(".create-character");
  if (createButton) {
    createButton.addEventListener("click", () => {
      alert("Redirecting to character creation...");
    });
  }
});

// Función para abrir la ventana de chat
function openChatWindow(imageSrc, title, description) {
  const chatWindow = document.getElementById("chatWindow");
  const chatImage = document.getElementById("chatImage");
  const chatTitle = document.getElementById("chatTitle");
  const chatDescription = document.getElementById("chatDescription");

  // Llenar la ventana con los datos del personaje
  chatImage.src = imageSrc;
  chatTitle.textContent = title;
  chatDescription.textContent = description;

  // Mostrar la ventana
  chatWindow.style.display = "block";
}

// Función para cerrar la ventana de chat
function closeChatWindow() {
  const chatWindow = document.getElementById("chatWindow");
  chatWindow.style.display = "none";
}

// Evento para los botones "Chat Now"
document.addEventListener("DOMContentLoaded", () => {
  const chatButtons = document.querySelectorAll(".chat-button");

  chatButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const card = button.closest(".character-card");
      const imageSrc = card.querySelector("img").src;
      const title = card.querySelector("h2").textContent;
      const description = card.querySelector("p").textContent;

      openChatWindow(imageSrc, title, description);
    });
  });

  // Evento para el botón "Close"
  const closeButton = document.querySelector(".close-button");
  if (closeButton) {
    closeButton.addEventListener("click", closeChatWindow);
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const chatButtons = document.querySelectorAll(".chat-button");
  const characterInfo = document.getElementById("character-info");
  const backButton = document.getElementById("back-button");
  const goToChatButton = document.getElementById("go-to-chat");
  const mainContent = document.querySelector(".main-content");

  chatButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const card = this.parentElement;
      const imgSrc = card.querySelector("img").src;
      const name = card.querySelector("h2").textContent;
      const description = card.querySelector("p").textContent;

      // Mostrar los datos en la sección de información
      document.getElementById("character-img").src = imgSrc;
      document.getElementById("character-name").textContent = name;
      document.getElementById("character-description").textContent =
        description;

      // Agregar desenfoque al fondo
      mainContent.classList.add("blur");

      // Mostrar la sección de detalles
      characterInfo.classList.remove("hidden");
    });
  });

  // Botón de regresar
  backButton.addEventListener("click", () => {
    characterInfo.classList.add("hidden");
    mainContent.classList.remove("blur");
  });

  // Botón de ir al chat (redirige a otra página o muestra otra sección)
  goToChatButton.addEventListener("click", () => {
    alert(
      "Redirigiendo al chat de " +
        document.getElementById("character-name").textContent
    );
    // Aquí podrías redirigir a otra página con window.location.href
  });
});
