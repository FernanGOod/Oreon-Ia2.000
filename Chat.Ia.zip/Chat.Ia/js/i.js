document.addEventListener("DOMContentLoaded", function () {
  const chatBox = document.getElementById("chatBox");
  const messageInput = document.getElementById("messageInput");
  const sendButton = document.querySelector(".send-button");
  const uploadButton = document.querySelector(".upload-button");
  const fileInput = document.getElementById("fileInput");

  const API_ICHIGO =
    "https://magicloops.dev/api/loop/b7866a21-e25a-452b-9b92-34b3763dd4bc/run";

  sendButton.addEventListener("click", async function () {
    const message = messageInput.value.trim();
    if (!message) return;

    addMessage("user", message);
    messageInput.value = "";

    try {
      const response = await fetch(API_ICHIGO, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message }),
      });

      if (!response.ok) {
        throw new Error(
          `Error en la API: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      console.log("Respuesta de la API de Ichigo:", data);

      const botResponse =
        data.output ??
        data.response ??
        data.message ??
        JSON.stringify(data, null, 2);

      if (botResponse) {
        addMessage("bot", botResponse);
      } else {
        addMessage("bot", "No response received!");
      }
    } catch (error) {
      console.error("Error al llamar a la API:", error);
      addMessage("bot", "Hubo un problema al procesar tu mensaje. 😔");
    }
  });

  uploadButton.addEventListener("click", function () {
    fileInput.click();
  });

  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
      addMessage("user", `📷 Sent an image: ${file.name}`);
    }
  });

  function addMessage(sender, text) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender);
    messageDiv.innerHTML = `<p>${text}</p>`;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
});
