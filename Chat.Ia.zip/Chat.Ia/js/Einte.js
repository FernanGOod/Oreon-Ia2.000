document.addEventListener("DOMContentLoaded", function () {
  const chatBox = document.getElementById("chatBox");
  const messageInput = document.getElementById("messageInput");
  const sendButton = document.querySelector(".send-button");
  const uploadButton = document.querySelector(".upload-button");
  const fileInput = document.getElementById("fileInput");

  const API_ENDPOINT =
    "https://magicloops.dev/api/loop/af8ee3e8-f1b4-4e7c-94e3-3fcc4f24cc1a/run"; // Nueva URL

  // Función para enviar el mensaje
  async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message) return;

    addMessage("user", message);
    messageInput.value = ""; // Limpiar el campo de entrada

    try {
      const response = await fetch(API_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ input: message }), // Mensaje ingresado por el usuario
      });

      if (!response.ok) {
        throw new Error(
          `Error en la API: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      console.log("Respuesta completa de la API:", data); // Muestra la respuesta de la API

      const botResponse =
        data.output ?? data.response ?? JSON.stringify(data, null, 2);

      if (botResponse) {
        addMessage("bot", botResponse);
      } else {
        addMessage("bot", "No response received!");
      }
    } catch (error) {
      console.error("Error al llamar a la API:", error);
      addMessage("bot", "Hubo un problema al procesar tu mensaje. 😔");
    }
  }

  // Enviar mensaje al presionar el botón "Enviar"
  sendButton.addEventListener("click", sendMessage);

  // Enviar mensaje al presionar la tecla "Enter"
  messageInput.addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      event.preventDefault(); // Evitar salto de línea
      sendMessage();
    }
  });

  // Subir archivo al hacer clic en el botón de carga
  uploadButton.addEventListener("click", function () {
    fileInput.click();
  });

  // Manejar el archivo seleccionado
  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
      addMessage("user", `📷 Sent an image: ${file.name}`);
    }
  });

  // Función para agregar mensajes al chat
  function addMessage(sender, text) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender);
    messageDiv.innerHTML = `<p>${text}</p>`;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight; // Desplazar hacia el final del chat
  }
});
