document.addEventListener("DOMContentLoaded", function () {
  const chatBox = document.getElementById("chatBox");
  const messageInput = document.getElementById("messageInput");
  const sendButton = document.querySelector(".send-button");
  const uploadButton = document.querySelector(".upload-button");
  const fileInput = document.getElementById("fileInput");

  const API_NARUTO =
    "https://magicloops.dev/api/loop/8a497012-e8fa-4c7f-bebd-123d2562884f/run";

  sendButton.addEventListener("click", async function () {
    const message = messageInput.value.trim();
    if (!message) return;

    addMessage("user", message);
    messageInput.value = "";

    try {
      const response = await fetch(API_NARUTO, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message }),
      });

      if (!response.ok) {
        throw new Error(
          `Error en la API: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      console.log("Respuesta de la API de Naruto:", data);

      const botResponse =
        data.output ??
        data.response ??
        data.message ??
        JSON.stringify(data, null, 2);

      if (botResponse) {
        addMessage("bot", botResponse);
      } else {
        addMessage("bot", "No response received!");
      }
    } catch (error) {
      console.error("Error al llamar a la API:", error);
      addMessage("bot", "Hubo un problema al procesar tu mensaje. 😔");
    }
  });

  uploadButton.addEventListener("click", function () {
    fileInput.click();
  });

  fileInput.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
      addMessage("user", `📷 Sent an image: ${file.name}`);
    }
  });

  function addMessage(sender, text) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender);
    messageDiv.innerHTML = `<p>${text}</p>`;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
});
